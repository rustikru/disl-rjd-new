<?php
declare(strict_types=1);

use App\Database\QueryLogger;
use App\Middleware\ErrorHandler;
use Slim\Exception\HttpNotFoundException;

require __DIR__ . '/../vendor/autoload.php';

$config = require __DIR__ . '/../src/Config.php';

//  лог SQL-запросов
if (!empty($config['app_debug'])) {
    QueryLogger::enable(__DIR__ . '/../tmp/log/sql_debug.log');
}

$app = \Slim\Factory\AppFactory::create();

$isDev = $config['app_env'] === 'development';

if ($config['base_path'] !== '') {
    $app->setBasePath($config['base_path']);
}

$app->addBodyParsingMiddleware();

(require __DIR__ . '/../src/routes.php')($app, $config);

// Обработчик ошибок добавляется последним, чтобы перехватывать исключения
// из всех middleware, включая подключение к БД при проверке сессии.
$errorMiddleware = $app->addErrorMiddleware($isDev, true, $isDev);

$errorMiddleware->setDefaultErrorHandler(
    new ErrorHandler($app->getResponseFactory(), $config)
);

$errorMiddleware->setErrorHandler(
    HttpNotFoundException::class,
    function ($request, $exception) use ($app, $config) {
        $response = $app->getResponseFactory()->createResponse(404);
        $basePath = $config['base_path'] ?? '';
        $appName = $config['app_name'] ?? '';
        $user = $_SESSION['user'] ?? [];
        $headerSub = '';
        $headerRight = '';

        ob_start();
        require __DIR__ . '/../templates/404.php';
        $html = ob_get_clean();

        $response->getBody()->write($html);
        return $response;
    }
);

$app->run();
