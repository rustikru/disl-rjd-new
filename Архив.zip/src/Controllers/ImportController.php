<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Logging\ErrorLogger;
use App\Services\Logging\AuditLog;
use App\Database\DbInterface;
use App\Reports\ReportConfig;
use App\Services\Auth\Authorization;
use App\Services\Data\Organizations;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Message\UploadedFileInterface;

class ImportController
{
    private DbInterface $db;
    private array $config;
    private Organizations $organizations;

    /** Поля, которые хранятся как DATE в БД (Excel: 'DD.MM.YYYY' или 'DD.MM.YYYY HH:MI') */
    private const DATE_FIELDS = [
        'trip_start_dt',
        'trip_end_dt',
        'oper_dt',
        'asoup_depart_dt',
        'asoup_arrive_dt',
        'state_assign_dt',
        'norm_delivery_dt',
        'reg_date',
        'build_date',
        'next_repair_dt',
        'last_cap_repair_dt',
        'last_dep_repair_dt',
        'exclude_date',
        'life_ext_date',
        'lease_end_date',
        'service_life',
    ];

    /** Поля, которые хранятся как NUMBER в БД */
    private const NUMBER_FIELDS = [
        'cargo_weight_kg',
        'mileage_loaded_km',
        'mileage_empty_km',
        'mileage_total_km',
        'mileage_norm_km',
        'mileage_remain_km',
        'dist_passed_km',
        'dist_remain_km',
        'dist_total_km',
        'idle_time_days',
        'days_to_repair',
        'days_no_oper',
        'days_no_move',
        'tare_weight',
        'load_capacity',
        'length_mm',
        'body_volume',
        'axles_count',
        'seals_count',
        'loaded_containers',
        'empty_containers',
        'wagon_in_train',
        'body_material_code',
        'life_ext_sign',
        'repair_by_mileage',
        'lease_sign',
        'boiler_caliber',
    ];

    public function __construct(
        DbInterface $db,
        array $config = [],
        ?Organizations $organizations = null
    )
    {
        $this->db = $db;
        $this->config = $config;
        $this->organizations = $organizations ?? new Organizations($db);
    }

    /** GET /import */
    public function showForm(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $filter = $this->organizations->filter();
        $reports = $this->db->fetchAll(
            "SELECT to_char((report_dt),'DD.MM.YYYY HH24:MI:SS') AS report_date,
                    to_char((report_dt),'YYYY-MM-DD HH24:MI:SS') AS report_key,
                    type_reference, COUNT(*) AS cnt
             FROM xx_dislocation_rjd
             WHERE {$filter['sql']}
             GROUP BY to_char((report_dt),'DD.MM.YYYY HH24:MI:SS'), (report_dt), type_reference
             ORDER BY (report_dt) DESC, type_reference",
            $filter['params']
        );

        $appName  = $this->config['app_name'] ?? 'Дислокация РЖД';
        $basePath = $this->config['base_path'] ?? '';
        $user     = $_SESSION['user'] ?? [];
        $csrf = $_SESSION['csrf_token'] ?? '';
        $canDelete = Authorization::isAdmin($user);
        $uploadLimit = ini_get('upload_max_filesize') ?: 'не задан';
        $postLimit   = ini_get('post_max_size') ?: 'не задан';

        ob_start();
        include __DIR__ . '/../../templates/import.php';
        $html = ob_get_clean();

        $response->getBody()->write($html);
        return $response->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    /** GET /import/download */
    public function downloadReference(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $memoryLimit = trim((string) ($this->config['report_mail_memory_limit'] ?? ''));
        if ($memoryLimit !== '') {
            ini_set('memory_limit', $memoryLimit);
        }

        $params = $request->getQueryParams();
        $reportDt = trim((string) ($params['report_dt'] ?? ''));
        $type = trim((string) ($params['type_reference'] ?? ''));
        $organizationId = $this->organizations->id();
        if ($organizationId === null
            || !preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $reportDt)
            || !in_array($type, ['Подход', 'Отправка'], true)) {
            return $this->redirect($response, '/import?error=' . rawurlencode('Некорректные параметры справки'));
        }

        try {
            $columns = ReportConfig::sourceColumns();
            $select = implode(', ', array_map(
                static fn(array $column): string => strtoupper((string) $column['key']) . ' AS "' . $column['key'] . '"',
                $columns
            ));
            $rows = $this->db->fetchAll(
                "SELECT $select
                   FROM xx_dislocation_rjd
                  WHERE organization_id = :organization_id
                    AND report_dt = TO_DATE(:report_dt, 'YYYY-MM-DD HH24:MI:SS')
                    AND type_reference = :type_reference
                  ORDER BY wagon_no",
                ['organization_id' => $organizationId, 'report_dt' => $reportDt, 'type_reference' => $type]
            );
            if (!$rows) {
                return $this->redirect($response, '/import?warn=' . rawurlencode('Справка не найдена'));
            }
            $date = \DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $reportDt);
            $dateLabel = $date ? $date->format('d.m.Y H:i:s') : $reportDt;
            $fileDate = $date ? $date->format('Y-m-d_H-i-s') : date('Y-m-d_H-i-s');

            return \App\ExcelExport::downloadReference(
                $response,
                $columns,
                $rows,
                'Справка РЖД - ' . $type,
                $dateLabel,
                'Справка_РЖД_' . $type . '_' . $fileDate
            );
        } catch (\Throwable $error) {
            $code = ErrorLogger::logThrowable($error, [
                'operation' => 'download_import_reference',
                'organization_id' => $organizationId,
                'report_dt' => $reportDt,
                'type_reference' => $type,
            ], $request);
            return $this->redirect($response, '/import?error=' . rawurlencode('Не удалось сформировать справку. Код ошибки: ' . $code));
        }
    }

    /** POST /import/delete */
    public function deleteReference(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $body = (array) $request->getParsedBody();
        if (!Authorization::isAdmin()) return $response->withStatus(403);
        if (empty($body['csrf_token']) || !hash_equals((string) ($_SESSION['csrf_token'] ?? ''), (string) $body['csrf_token'])) {
            return $response->withStatus(403);
        }
        $reportDt = trim((string) ($body['report_dt'] ?? ''));
        $type = trim((string) ($body['type_reference'] ?? ''));
        $organizationId = $this->organizations->id();
        if ($organizationId === null || !preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $reportDt)
            || $type === '' || mb_strlen($type) > 50) {
            return $this->redirect($response, '/import?error=' . rawurlencode('Некорректные параметры справки'));
        }
        try {
            $row = $this->db->fetchOne(
                "SELECT COUNT(*) AS cnt FROM xx_dislocation_rjd
                  WHERE organization_id = :organization_id
                    AND report_dt = TO_DATE(:report_dt, 'YYYY-MM-DD HH24:MI:SS')
                    AND type_reference = :type_reference",
                ['organization_id' => $organizationId, 'report_dt' => $reportDt, 'type_reference' => $type]
            );
            $count = (int) ($row['cnt'] ?? 0);
            if ($count < 1) return $this->redirect($response, '/import?warn=' . rawurlencode('Справка уже удалена'));
            $this->db->execute(
                "BEGIN XX_ETW.XX_RJD_DISLOCATION_NEW_PKG.DELETE_REFERENCE(
                    TO_DATE(:report_dt, 'YYYY-MM-DD HH24:MI:SS'), :type_reference
                ); END;",
                ['report_dt' => $reportDt, 'type_reference' => $type]
            );
            (new AuditLog($this->db))->write(
                'IMPORT_DELETE', 'REFERENCE', $type,
                'Удалена справка: ' . $count . ' строк, дата ' . $reportDt
            );
        } catch (\Throwable $error) {
            $code = ErrorLogger::logThrowable($error, [
                'operation' => 'delete_import_reference',
                'organization_id' => $organizationId,
                'report_dt' => $reportDt,
                'type_reference' => $type,
            ], $request);
            return $this->redirect($response, '/import?error=' . rawurlencode('Не удалось удалить справку. Код ошибки: ' . $code));
        }
        return $this->redirect($response, '/import?success=' . rawurlencode('Справка удалена'));
    }

    /** POST /import */
    public function handleUpload(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $uploadedFiles = $request->getUploadedFiles();

        $files = $uploadedFiles['xlsx_files'] ?? [];
        if (empty($files)) {
            return $this->redirect($response, '/import?error=' . urlencode('Файл не выбран'));
        }
        if (!is_array($files)) {
            $files = [$files];
        }

        $successes = [];
        $warns = [];
        $errors = [];

        foreach ($files as $file) {
            /** @var UploadedFileInterface $file */
            $name = $file->getClientFilename() ?: 'файл';

            if ($file->getError() !== UPLOAD_ERR_OK) {
                $errors[] = '«' . $name . '»: ошибка загрузки (код ' . $file->getError() . ')';
                continue;
            }

            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($ext, ['xlsx'], true)) {
                $errors[] = '«' . $name . '»: допускаются только файлы .xlsx';
                continue;
            }

            $tmpPath = sys_get_temp_dir() . '/rzd_import_' . uniqid() . '.' . $ext;
            try {
                $file->moveTo($tmpPath);
                $result = $this->importLocalFile($tmpPath);
            } catch (\Throwable $e) {
                @unlink($tmpPath);
                $code = ErrorLogger::logThrowable($e, [
                    'operation' => 'import_reference',
                    'file_name' => $name,
                ], $request);
                $errors[] = '«' . $name . '»: не удалось загрузить справку. Код ошибки: ' . $code;
                continue;
            }

            @unlink($tmpPath);

            if ($result['skipped']) {
                $warns[] = '«' . $name . '»: справка «' . $result['type'] . '» на ' . $result['report_dt'] . ' уже загружена';
            } elseif (!$result['current_updated']) {
                $successes[] = '«' . $name . '»: архив дополнен данными на ' . $result['report_dt']
                    . '; в текущей таблице оставлена более поздняя справка на ' . $result['latest_report_dt'];
                (new AuditLog($this->db))->write(
                    'IMPORT_UPLOAD',
                    'REFERENCE',
                    (string) $result['type'],
                    'Архив дополнен из файла «' . $name . '» на ' . $result['report_dt']
                        . '; текущая справка ' . $result['latest_report_dt']
                );
            } else {
                $successes[] = '«' . $name . '»: загружено ' . $result['rows'] . ' строк ('
                    . $result['type'] . ', ' . $result['report_dt'] . ')';
                (new AuditLog($this->db))->write(
                    'IMPORT_UPLOAD',
                    'REFERENCE',
                    (string) $result['type'],
                    'Загружен файл «' . $name . '»: ' . $result['rows'] . ' строк, дата ' . $result['report_dt']
                );
            }
        }

        if (!empty($errors)) {
            $all = array_merge($successes, $warns, $errors);
            return $this->redirect($response, '/import?error=' . urlencode(implode("\n", $all)));
        }
        if (!empty($warns)) {
            $all = array_merge($successes, $warns);
            return $this->redirect($response, '/import?warn=' . urlencode(implode("\n", $all)));
        }
        return $this->redirect($response, '/import?success=' . urlencode(implode("\n", $successes)));
    }

    /** POST /api/import/file — загрузка одного файла, возвращает JSON */
    public function handleUploadJson(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        $uploadedFiles = $request->getUploadedFiles();
        $file = $uploadedFiles['file'] ?? null;

        if (!$file) {
            return $this->jsonResponse($response, 422, ['status' => 'error', 'message' => 'Файл не передан']);
        }

        if ($file->getError() !== UPLOAD_ERR_OK) {
            return $this->jsonResponse($response, 422, [
                'status' => 'error',
                'message' => $this->uploadErrorMessage($file->getError()),
            ]);
        }

        $name = $file->getClientFilename() ?: 'file';
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!in_array($ext, ['xlsx'], true)) {
            return $this->jsonResponse($response, 422, ['status' => 'error', 'message' => 'Допускаются только .xlsx']);
        }

        $tmpPath = sys_get_temp_dir() . '/rzd_import_' . uniqid() . '.' . $ext;
        try {
            $file->moveTo($tmpPath);
            $result = $this->importLocalFile($tmpPath);
        } catch (\Throwable $e) {
            @unlink($tmpPath);
            $code = ErrorLogger::logThrowable($e, [
                'operation' => 'import_reference_api',
                'file_name' => $name,
            ], $request);
            return $this->jsonResponse($response, 500, [
                'status' => 'error',
                'message' => 'Не удалось загрузить справку',
                'code' => $code,
            ]);
        }

        @unlink($tmpPath);

        if ($result['skipped']) {
            return $this->jsonResponse($response, 200, [
                'status' => 'warn',
                'message' => 'Справка «' . $result['type'] . '» на ' . $result['report_dt'] . ' уже загружена',
                'report_dt' => $result['report_dt'],
                'type' => $result['type'],
            ]);
        }

        (new AuditLog($this->db))->write(
            'IMPORT_UPLOAD',
            'REFERENCE',
            (string) $result['type'],
            $result['current_updated']
                ? 'Загружен файл «' . $name . '»: ' . $result['rows'] . ' строк, дата ' . $result['report_dt']
                : 'Архив дополнен из файла «' . $name . '» на ' . $result['report_dt']
                    . '; текущая справка ' . $result['latest_report_dt']
        );

        return $this->jsonResponse($response, 200, [
            'status' => 'ok',
            'message' => $result['current_updated']
                ? 'Загружено ' . $result['rows'] . ' строк'
                : 'Архив дополнен; в текущей таблице оставлена справка на ' . $result['latest_report_dt'],
            'rows' => $result['rows'],
            'report_dt' => $result['report_dt'],
            'type' => $result['type'],
            'current_updated' => $result['current_updated'],
            'latest_report_dt' => $result['latest_report_dt'],
        ]);
    }

    private function jsonResponse(ResponseInterface $response, int $status, array $data): ResponseInterface
    {
        $response->getBody()->write(json_encode($data, JSON_UNESCAPED_UNICODE));
        return $response->withStatus($status)->withHeader('Content-Type', 'application/json; charset=utf-8');
    }

    private function uploadErrorMessage(int $error): string
    {
        return match ($error) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Файл превышает лимит загрузки PHP: upload_max_filesize='
                . ini_get('upload_max_filesize') . ', post_max_size=' . ini_get('post_max_size'),
            UPLOAD_ERR_PARTIAL => 'Файл загружен не полностью',
            UPLOAD_ERR_NO_FILE => 'Файл не передан',
            UPLOAD_ERR_NO_TMP_DIR => 'Не найдена временная папка для загрузки',
            UPLOAD_ERR_CANT_WRITE => 'Не удалось записать файл на диск',
            UPLOAD_ERR_EXTENSION => 'Загрузка остановлена расширением PHP',
            default => 'Ошибка загрузки файла (код ' . $error . ')',
        };
    }

    /**
     * Импорт локального XLSX теми же правилами, что и ручная форма.
     * Используется также отдельной ручной страницей из bin.
     */
    public function importLocalFile(string $path): array
    {
        ini_set('memory_limit', '512M');

        $organizationId = $this->organizations->id();
        if ($organizationId === null) {
            throw new \RuntimeException('Пользователю не назначена организация');
        }
        if (!$this->organizations->isMtf()) {
            throw new \RuntimeException('Для выбранной организации не настроено определение типа справки');
        }

        $reader = IOFactory::createReaderForFile($path);
        $reader->setReadDataOnly(true);
        $spreadsheet = $reader->load($path);
        $sheet = $spreadsheet->getActiveSheet();

        // Дата справки из ячейки A2 (формат: '10.06.2026 16:01')
        $rawDt = trim((string) $sheet->getCell('A2')->getValue());
        $reportDt = $this->parseReportDate($rawDt);

        $highestRow = $sheet->getHighestRow();

        // Определяем тип справки по dest_station (кол. 12) первой непустой строки
        $fileType = $this->detectFileType($sheet, $highestRow);

        $fields = $this->columnFieldNames();
        $placeholders = array_map(fn($i) => ':p' . $i, array_keys($fields));
        $insertSql = 'INSERT INTO xx_dislocation_rjd (organization_id, report_dt, type_reference, ' . implode(', ', $fields) . ')'
            . ' VALUES (:p_organization_id, :p_report_dt, :p_type_reference, ' . implode(', ', $placeholders) . ')';

        $reportDate = substr($reportDt, 0, 10); // 'YYYY-MM-DD'
        $latestRow = $this->db->fetchOne(
            "SELECT TO_CHAR(MAX(report_dt), 'YYYY-MM-DD HH24:MI:SS') AS report_dt
               FROM xx_dislocation_rjd
              WHERE TRUNC(report_dt) = TO_DATE(:p_report_date, 'YYYY-MM-DD')
                AND type_reference = :p_file_type
                AND organization_id = :p_organization_id",
            [
                'p_report_date' => $reportDate,
                'p_file_type' => $fileType,
                'p_organization_id' => $organizationId,
            ]
        );
        $latestReportDt = trim((string) ($latestRow['report_dt'] ?? ''));
        $isOlder = $latestReportDt !== '' && strcmp($reportDt, $latestReportDt) < 0;
        $inserted = 0;

        $this->db->beginTransaction();
        try {
            // Замена справки атомарна: при ошибке вставки удаление также откатится.
            if ($isOlder) {
                $this->db->execute(
                    "DELETE FROM xx_dislocation_rjd
                      WHERE report_dt = TO_DATE(:p_report_dt, 'YYYY-MM-DD HH24:MI:SS')
                        AND type_reference = :p_file_type
                        AND organization_id = :p_organization_id",
                    [
                        'p_report_dt' => $reportDt,
                        'p_file_type' => $fileType,
                        'p_organization_id' => $organizationId,
                    ]
                );
            } else {
                $this->db->execute(
                    "DELETE FROM xx_dislocation_rjd
                      WHERE TRUNC(report_dt) = TO_DATE(:p_report_date, 'YYYY-MM-DD')
                        AND type_reference = :p_file_type
                        AND organization_id = :p_organization_id",
                    [
                        'p_report_date' => $reportDate,
                        'p_file_type' => $fileType,
                        'p_organization_id' => $organizationId,
                    ]
                );
            }

            for ($row = 5; $row <= $highestRow; $row++) {
                $vals = [];
                for ($col = 1; $col <= 126; $col++) {
                    $coord = Coordinate::stringFromColumnIndex($col) . $row;
                    $v = $sheet->getCell($coord)->getValue();
                    $vals[] = ($v === null) ? null : $this->normalizeImportedValue((string) $v);
                }

                if (empty(array_filter($vals, fn($v) => $v !== null && $v !== ''))) {
                    continue;
                }

                $destStation = $vals[11] ?? '';
                $typeRef = ($destStation === 'УГЛЕУРАЛЬСКАЯ (768207)') ? 'Подход' : 'Отправка';

                $params = [
                    'p_organization_id' => $organizationId,
                    'p_report_dt' => $reportDt,
                    'p_type_reference' => $typeRef,
                ];
                foreach ($fields as $i => $field) {
                    $params['p' . $i] = $this->castValue($field, $vals[$i] ?? null);
                }
                $this->db->execute($insertSql, $params);
                $inserted++;
            }

            $this->db->execute(
                "BEGIN XX_ETW.XX_RJD_DISLOCATION_NEW_PKG.ARCHIVE_RJD_MOVEMENT(
                    TO_DATE(:p_report_dt, 'YYYY-MM-DD HH24:MI:SS'), :p_type_reference
                ); END;",
                ['p_report_dt' => $reportDt, 'p_type_reference' => $fileType]
            );

            if ($isOlder) {
                $this->db->execute(
                    "DELETE FROM xx_dislocation_rjd
                      WHERE report_dt = TO_DATE(:p_report_dt, 'YYYY-MM-DD HH24:MI:SS')
                        AND type_reference = :p_file_type
                        AND organization_id = :p_organization_id",
                    [
                        'p_report_dt' => $reportDt,
                        'p_file_type' => $fileType,
                        'p_organization_id' => $organizationId,
                    ]
                );
            }
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollback();
            throw $e;
        } finally {
            $spreadsheet->disconnectWorksheets();
            unset($spreadsheet);
        }

        return [
            'skipped' => false,
            'report_dt' => $rawDt,
            'type' => $fileType,
            'rows' => $inserted,
            'current_updated' => !$isOlder,
            'latest_report_dt' => $latestReportDt,
        ];
    }

    private function parseReportDate(string $raw): string
    {
        $raw = trim($raw, " '\"\u{2018}\u{2019}");
        if (preg_match('/^(\d{2})\.(\d{2})\.(\d{4})\s+(\d{2}:\d{2})/', $raw, $m)) {
            return "{$m[3]}-{$m[2]}-{$m[1]} {$m[4]}:00";
        }
        throw new \RuntimeException("Не удалось разобрать дату справки из ячейки A2: «{$raw}»");
    }

    /** Исправляет символ, которым в справке иногда записывается кириллическая «З». */
    private function normalizeImportedValue(string $value): string
    {
        return trim(str_replace("▤", 'З', $value));
    }

    private function columnFieldNames(): array
    {
        return array_column(ReportConfig::sourceColumns(), 'key');
    }

    /**
     * Определяет тип справки по первой непустой dest_station (кол. 12 = столбец L).
     * 'УГЛЕУРАЛЬСКАЯ (768207)' → 'Подход', всё остальное → 'Отправка'.
     */
    private function detectFileType(
        \PhpOffice\PhpSpreadsheet\Worksheet\Worksheet $sheet,
        int $highestRow
    ): string {
        for ($row = 5; $row <= min(35, $highestRow); $row++) {
            $val = trim((string) ($sheet->getCell('L' . $row)->getValue() ?? ''));

            if ($val !== '') {
                return str_contains($val, '768207') ? 'Подход' : 'Отправка';
            }
        }

        return 'Отправка';
    }

    /** Приводит строку из Excel к нужному типу для вставки в БД. */
    private function castValue(string $field, ?string $raw): string|int|float|null
    {
        if ($raw === null || $raw === '') {
            return null;
        }

        if (in_array($field, self::DATE_FIELDS, true)) {
            return $this->parseExcelDate($raw);
        }

        if (in_array($field, self::NUMBER_FIELDS, true)) {
            // Убираем пробелы (обычные и неразрывные) — разделители тысяч из Excel
            $clean = str_replace([' ', "\u{00A0}", "\xc2\xa0"], '', $raw);
            return is_numeric($clean) ? $clean + 0 : null;
        }

        return $raw;
    }

    /**
     * Парсит дату Excel в формат 'YYYY-MM-DD HH:MI:SS' (NLS_DATE_FORMAT сессии Oracle).
     * Входные форматы: 'DD.MM.YYYY HH:MI[:SS]' или 'DD.MM.YYYY'.
     * Если передана числовая строка — трактует как серийный номер даты Excel.
     */
    private function parseExcelDate(string $raw): ?string
    {
        // 'DD.MM.YYYY HH:MI' или 'DD.MM.YYYY HH:MI:SS'
        if (preg_match('/^(\d{2})\.(\d{2})\.(\d{4})\s+(\d{2}):(\d{2})(?::(\d{2}))?/', $raw, $m)) {
            $sec = isset($m[6]) && $m[6] !== '' ? $m[6] : '00';
            return "{$m[3]}-{$m[2]}-{$m[1]} {$m[4]}:{$m[5]}:{$sec}";
        }

        // 'DD.MM.YYYY'
        if (preg_match('/^(\d{2})\.(\d{2})\.(\d{4})$/', $raw, $m)) {
            return "{$m[3]}-{$m[2]}-{$m[1]} 00:00:00";
        }

        // Excel serial date (число дней с 01.01.1900)
        if (is_numeric($raw)) {
            $ts = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToTimestamp((float) $raw);
            return date('Y-m-d H:i:s', $ts);
        }

        return null;
    }

    private function redirect(ResponseInterface $response, string $url): ResponseInterface
    {
        $base = $this->config['base_path'] ?? '';
        return $response->withHeader('Location', $base . $url)->withStatus(302);
    }
}
