CREATE OR REPLACE package XX_ETW.xx_rjd_dislocation_new_pkg
as
    /******************************************************************************
    NAME:  xx_etw.xx_rjd_dislocation_new_pkg
    PURPOSE:   Метафракс: Дислокация РЖД (справка из кабинета)
    REVISIONS:
    Ver        Date        Author           Description
    ---------  ----------  ---------------  ------------------------------------
    1.0        15.06.2026  BekmansurovRR    1. Created this package.
 ******************************************************************************/
    function fnc_mapping_wag_type (p_wag_name in varchar2)
        return varchar2;

    function get_organization_id
        return number;

    type latest_report_rec is record
    (
        type_reference   varchar2 (50),
        report_dt        date
    );

    type latest_report_tab is table of latest_report_rec;

    function get_latest_reports (p_type_1       in varchar2 default 'Подход',
                                 p_type_2       in varchar2 default 'Отправка',
                                 p_report_day   in date default null)
        return latest_report_tab
        pipelined;

    procedure set_org_id (p_org_code varchar2);
    function fnc_get_downtime_wagon (p_downtime   in number,
                                     p_type       in varchar2 default 'name')
        return varchar2;

    function fnc_get_state_wagon (p_weight in number)
        return varchar2;

    function fnc_get_cargo_state (p_wagon_type_code   in varchar2,
                                  p_weight             in number)
        return varchar2 deterministic;

    function fnc_get_pn_cargo_state (p_railcar_id in varchar2)
        return varchar2;

    function fnc_get_approach_cargo_state (
        p_oper_station      in varchar2,
        p_railcar_id        in varchar2,
        p_wagon_type_code   in varchar2,
        p_weight             in number
    ) return varchar2;

    function set_kpi_label (p_kpi_id in number, p_date in date default null)
        return varchar2;

    function fnc_check_kpi (p_kpi_id in number, p_disl_rjd_id in number)
        return number;

    function fnc_get_kpi_trend_pct (p_id in number)
        return varchar2;

    function fnc_get_kpi_trend_dir (p_id in number)
        return varchar2;

    function get_kpi_row (p_kpi_id in number)
        return t_xx_rjd_kpi_tab
        pipelined;

    type page_kpi_rec is record
    (
        id             number,
        code           varchar2 (100),
        type           varchar2 (100),
        x_label        varchar2 (500),
        x_value        varchar2 (4000),
        trend_pct      varchar2 (100),
        trend_dir      varchar2 (10),
        trend_period   varchar2 (20),
        order_by       number,
        is_error       varchar2 (1),
        is_system      varchar2 (1),
        owner_id       number,
        visibility     varchar2 (20),
        where_config   varchar2 (4000),
        detail_type    varchar2 (20),
        detail_profile varchar2 (50),
        group_title    varchar2 (200),
        count_label    varchar2 (100),
        empty_label    varchar2 (200),
        report_dt      varchar2 (20)
    );

    type page_kpi_tab is table of page_kpi_rec;

    function get_page_kpi (p_kpi_type in varchar2, p_user_id in number)
        return page_kpi_tab
        pipelined;

    function get_kpi_where (p_kpi_id in number)
        return varchar2;

    function get_report_where (p_page in varchar2,
                               p_alias in varchar2 default null)
        return varchar2;

    procedure archive_rjd_movement (p_report_dt        in date,
                                    p_type_reference   in varchar2);

    procedure parse_rjd_excel (p_data in clob);

    procedure delete_reference (p_report_dt        in date,
                                p_type_reference   in varchar2);

    procedure get_rjd_excel_file (p_directory   in     varchar2,
                                  p_file_name      out varchar2,
                                  p_file_data      out blob);

    type station_rec is record
    (
        esr_code        varchar2 (20),
        station_name    varchar2 (255),
        latitude        varchar2 (255),
        longitude       varchar2 (255)
    );

    type station_tab is table of station_rec;

    type station_no_coord_rec is record
    (
        esr_code        varchar2 (20),
        station_name    varchar2 (255),
        wagon_count     number
    );

    type station_no_coord_tab is table of station_no_coord_rec;

    function stations (p_search   in varchar2 default null,
                       p_offset   in number default 0,
                       p_limit    in number default 50)
        return station_tab
        pipelined;

    function stations_count (p_search in varchar2 default null)
        return number;

    function station (p_esr_code in varchar2)
        return station_tab
        pipelined;

    function stations_no_coord
        return station_no_coord_tab
        pipelined;

    procedure save_station (p_esr_code       in varchar2,
                            p_station_name   in varchar2,
                            p_latitude       in number,
                            p_longitude      in number);

    procedure delete_station (p_esr_code in varchar2);

    procedure save_idle_control (p_id_control        in number,
                                 p_created_by        in number,
                                 p_car_number        in varchar2,
                                 p_start_date        in date,
                                 p_end_date          in date,
                                 p_note              in varchar2,
                                 p_is_excluded       in varchar2,
                                 p_idle_reasons_id   in number);

    procedure delete_idle_control (p_id_control   in number,
                                   p_deleted_by   in number);

    procedure save_idle_reason (p_id      in number,
                                p_name    in varchar2,
                                p_descr   in varchar2);

    procedure delete_idle_reason (p_id in number);

    procedure mail_start;

    procedure mail_add_file (p_file        in blob,
                             p_file_name   in varchar2,
                             p_mime_type   in varchar2);

    procedure mail_send (p_sender      in varchar2,
                         p_recipient   in varchar2,
                         p_subject     in varchar2,
                         p_text        in clob);

    function data_scope_predicate (p_schema varchar2, p_object varchar2)
        return varchar2;
end xx_rjd_dislocation_new_pkg;
/
